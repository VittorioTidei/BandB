package it.contrader.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jxl.write.DateTime;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@Entity
@Table(name = "carts")
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = Cart.class)
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate createdAt;

    private LocalDate updatedAt;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JsonManagedReference
    private User user;

    @OneToMany(mappedBy = "cart" ,cascade = CascadeType.ALL)
    @JsonBackReference
    private List<ProductCartList> productsCartList;

    public Cart(Long id, User user, List<ProductCartList> productsCartList) {
        this.id = id;
        this.user = user;
        this.productsCartList = productsCartList;
    }

    public Cart(Long id, User user) {
        this.id = id;
        this.user = user;
    }

    @PrePersist
    private void onCreate(){
        this.createdAt = LocalDate.now();
        this.updatedAt = LocalDate.now();
    }

    @PreUpdate
    private void onUpdate(){
        this.updatedAt = LocalDate.now();
    }
}
