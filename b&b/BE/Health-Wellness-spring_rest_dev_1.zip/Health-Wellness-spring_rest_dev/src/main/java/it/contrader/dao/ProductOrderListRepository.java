package it.contrader.dao;

import it.contrader.model.Order;
import it.contrader.model.ProductOrderList;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface ProductOrderListRepository extends CrudRepository<ProductOrderList, Long> {

    public List<ProductOrderList> getAllByOrderId(long id);


}
