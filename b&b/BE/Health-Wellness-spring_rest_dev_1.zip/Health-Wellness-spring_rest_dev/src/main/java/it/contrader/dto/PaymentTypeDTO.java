package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import it.contrader.model.Order;
import it.contrader.model.Treatment;
import lombok.*;

import javax.persistence.OneToMany;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = PaymentTypeDTO.class)
public class PaymentTypeDTO {

    private Long id;

    private String name;

    private String data;

    private List<OrderDTO> orders;

    public PaymentTypeDTO(Long id, String name, String data) {
        this.id = id;
        this.name = name;
        this.data = data;
    }
}
