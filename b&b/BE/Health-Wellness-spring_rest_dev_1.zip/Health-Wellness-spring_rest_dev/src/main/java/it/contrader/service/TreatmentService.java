package it.contrader.service;
import org.springframework.stereotype.Service;
import it.contrader.dto.TreatmentDTO;
import it.contrader.model.Treatment;
@Service
public class TreatmentService extends AbstractService<Treatment, TreatmentDTO>{
}
