package it.contrader.service;

import it.contrader.dao.OrderRepository;
import it.contrader.dao.ProductOrderListRepository;
import it.contrader.dto.OrderDTO;
import it.contrader.dto.ProductOrderListDTO;
import it.contrader.model.ProductOrderList;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductOrderListService extends AbstractService<ProductOrderList, ProductOrderListDTO> {

    public Iterable<ProductOrderListDTO> getAllByOrderId(long id){
        return converter.toDTOList(((ProductOrderListRepository)repository).getAllByOrderId(id));
    }
}
