package it.contrader.service;

import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.repository.CrudRepository;

import it.contrader.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;


/**
 * Questa classe astratta implementa tutti i metodi CRUD firmati in ServiceDTO.
 * Il converter agisce due volte nei metodi  insert e update per avere sia come input che come output
 * un oggetto DTO.
 * 
 * @author Vittorio Valent & Girolamo Murdaca
 *
 * @param <Entity>
 * @param <DTO>
 * 
 * @see ServiceDTO
 */

public abstract class AbstractService<Entity,DTO> implements ServiceDTO<DTO> {

	@Autowired
	protected CrudRepository<Entity,Long> repository;
	@Autowired
	protected Converter<Entity,DTO> converter;

	@Override
	public DTO insert(DTO dto) {
		return converter.toDTO(repository.save(converter.toEntity(dto)));
	}

	@Override
	public Iterable<DTO> insertAll(Iterable<DTO> dtoList) {
		return converter.toDTOList(repository.saveAll(converter.toEntityList(dtoList)));
	}

	@Override
	public Iterable<DTO> getAll() {
		return converter.toDTOList(repository.findAll());
	}

	@Override
	public DTO read(long id) {
		return converter.toDTO(repository.findById(id).get());
	}

	@Override
	public DTO update(DTO dto) {
		return converter.toDTO(repository.save(converter.toEntity(dto)));
	}

	@Override
	public void delete(long id) {
		repository.deleteById(id);
	}
	@Override
	public boolean existsById(long id) {
		return repository.existsById(id);
	}
/*

public abstract class AbstractService<Entity,DTO> implements ServiceDTO<DTO> {

	@Autowired
	protected CrudRepository<Entity,Long> repository;
	@Autowired
	protected Converter<Entity,DTO> converter;

	@Override
	//@SneakyThrows
	public DTO insert(DTO dto) {

		return converter.toDTO(repository.save(converter.toEntity(dto)));


	}
	//public DTO insert(DTO dto) {
	//	return converter.toDTO(repository.save(converter.toEntity(dto)));
	//}

	@Override
	public ResponseEntity<Iterable<DTO>> getAll(){
		return new ResponseEntity<Iterable<DTO>>(converter.toDTOList(repository.findAll()),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> read(long id) {

		if(repository.existsById(id))
			return new ResponseEntity<DTO>(converter.toDTO(repository.findById(id).get()),HttpStatus.OK);

		return new ResponseEntity<String>("Nessuna occorrenza trovata", HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> update(DTO dto) {
		try{
			Entity savedEntity = repository.save(converter.toEntity(dto));
			return new ResponseEntity<DTO>(converter.toDTO(savedEntity),HttpStatus.OK);
		}catch(IllegalArgumentException ex){
			return new ResponseEntity<String>( ex.toString(), HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public ResponseEntity<?> delete(long id) {
		if(repository.existsById(id)){
			repository.deleteById(id);
			return new ResponseEntity<String>("Eliminazione andata a buon fine!", HttpStatus.OK);
		}
		return new ResponseEntity<String>("Nessuna occorrenza trovata", HttpStatus.NOT_FOUND);
	}

	@Override
	public boolean existsById(long id) {
		return repository.existsById(id);
	}
	*/
}