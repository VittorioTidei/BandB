package it.contrader.service;


import it.contrader.dao.CenterRepository;
import it.contrader.dto.CenterDTO;
import it.contrader.model.Center;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class CenterService extends AbstractService<Center, CenterDTO>{

    @Autowired
    CenterRepository centerRepository;

    public Iterable<CenterDTO> getAllByUserId(long id){
        return converter.toDTOList(((CenterRepository)repository).getAllByUserId(id));
    }

    public Iterable<CenterDTO> getAllByUserIdNot(long id){
        return converter.toDTOList(((CenterRepository)repository).getAllByUserIdNot(id));
    }
}
