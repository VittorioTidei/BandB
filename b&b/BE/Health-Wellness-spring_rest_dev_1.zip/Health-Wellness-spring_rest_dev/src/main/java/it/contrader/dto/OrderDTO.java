package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import it.contrader.model.*;
import lombok.*;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = OrderDTO.class)
public class OrderDTO {

    private Long id;
    private float totalPrice;

    private UserDTO user;

    private CartDTO cart;

    private PaymentTypeDTO paymentType;

    private List<ProductOrderListDTO> productsOrderList;

    public OrderDTO(Long id, float totalPrice) {
        this.id = id;
        this.totalPrice = totalPrice;
    }
}
