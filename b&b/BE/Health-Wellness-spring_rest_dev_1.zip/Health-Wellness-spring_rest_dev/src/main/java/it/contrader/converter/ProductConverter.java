package it.contrader.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.contrader.dto.ProductDTO;

import it.contrader.model.Product;


@Component
public class ProductConverter extends AbstractConverter<Product, ProductDTO> {

    @Autowired
    private CenterConverter centerConverter;

    @Autowired
    private TreatmentConverter treatmentConverter;

    @Override
    public Product toEntity(ProductDTO productDTO) {
        Product product = null;
        if (productDTO != null)
            product = new Product(productDTO.getId(), productDTO.getTitle(), productDTO.getDescription(), productDTO.getPrice(), productDTO.getDiscount(), productDTO.getQty(), productDTO.getStartDiscountDate(), productDTO.getEndDiscountDate(), centerConverter.toEntityLazy(productDTO.getCenter()),treatmentConverter.toEntityLazy(productDTO.getTreatment()));

        return product;
    }
    public Product toEntityLazy(ProductDTO productDTO) {
        Product product = null;
        if (productDTO != null)
            product = new Product(productDTO.getId(), productDTO.getTitle(), productDTO.getDescription(), productDTO.getPrice(), productDTO.getDiscount(), productDTO.getQty(), productDTO.getStartDiscountDate(), productDTO.getEndDiscountDate(),treatmentConverter.toEntity(productDTO.getTreatment()) );

        return product;
    }

    @Override
    public ProductDTO toDTO(Product product) {
        ProductDTO productDTO = null;
        if (product != null)
            productDTO = new ProductDTO(product.getId(), product.getTitle(), product.getDescription(), product.getPrice(), product.getDiscount(), product.getQty(), product.getStartDiscountDate(), product.getEndDiscountDate(), centerConverter.toDTOLazy(product.getCenter()),treatmentConverter.toDTOLazy(product.getTreatment()));

        return productDTO;
    }

    public ProductDTO toDTOLazy(Product product) {
        ProductDTO productDTO = null;
        if (product != null)
            productDTO = new ProductDTO(product.getId(), product.getTitle(), product.getDescription(), product.getPrice(), product.getDiscount(), product.getQty(), product.getStartDiscountDate(), product.getEndDiscountDate(),treatmentConverter.toDTO(product.getTreatment()) );

        return productDTO;
    }
}
