package it.contrader.converter;

import it.contrader.dto.CenterDTO;
import it.contrader.dto.ProductCartListDTO;
import it.contrader.model.Center;
import it.contrader.model.ProductCartList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.Converter;
import java.util.ArrayList;
import java.util.List;

@Component
public class ProductCartListConverter extends  AbstractConverter<ProductCartList, ProductCartListDTO> {

    @Autowired
    private CartConverter cartConverter;
    @Autowired
    private ProductConverter productConverter;

    @Override
    public ProductCartList toEntity(ProductCartListDTO productCartListDTO) {
        ProductCartList productCartList = null;
        if (productCartListDTO != null)
            productCartList = new ProductCartList(productCartListDTO.getId(), productCartListDTO.getQty(),cartConverter.toEntityLazy(productCartListDTO.getCart()), productConverter.toEntity(productCartListDTO.getProduct()));
        return productCartList;
    }
    /*
    public ProductCartList toEntityLazy(ProductCartListDTO productCartListDTO) {
        ProductCartList productCartList = null;
        if (productCartListDTO != null)
            productCartList = new ProductCartList(productCartListDTO.getId(), productCartListDTO.getQty(),productConverter.toEntityLazy(productCartListDTO.getProduct()));
        return productCartList;
    }

    public List<ProductCartList> toEntityListLazy (Iterable<ProductCartListDTO> productsCartListDTO) {
        List<ProductCartList> list = new ArrayList<ProductCartList>();

        if(productsCartListDTO != null) {
            for (ProductCartListDTO dto : productsCartListDTO) {
                ProductCartList entity = toEntityLazy(dto);
                list.add(entity);
            }
        }
        return list;
    }
*/
    @Override
    public ProductCartListDTO toDTO(ProductCartList productCartList) {
        ProductCartListDTO productCartListDTO = null;
        if (productCartList != null)
            productCartListDTO = new ProductCartListDTO(productCartList.getId(), productCartList.getQty(),cartConverter.toDTOLazy(productCartList.getCart()), productConverter.toDTO(productCartList.getProduct()));

        return productCartListDTO;
    }
/*
    //Metodo che necessita di una revisione, funziona ma poco elegante per me
    public ProductCartListDTO toDTOLazy(ProductCartList productCartList) {
        ProductCartListDTO productCartListDTO = null;
        if (productCartList != null)
            productCartListDTO = new ProductCartListDTO(productCartList.getId(), productCartList.getQty(),productConverter.toDTOLazy(productCartList.getProduct()));

        return productCartListDTO;
    }

    //Metodo che necessita di una revisione, funziona ma poco elegante per me
    public List<ProductCartListDTO> toDTOListLazy (Iterable<ProductCartList> productsCartList) {
        List<ProductCartListDTO> list = new ArrayList<ProductCartListDTO>();

        if(productsCartList != null) {
            for (ProductCartList entity : productsCartList) {
                ProductCartListDTO dto = toDTOLazy(entity);
                list.add(dto);
            }
        }
        return list;
    }
    */

}
