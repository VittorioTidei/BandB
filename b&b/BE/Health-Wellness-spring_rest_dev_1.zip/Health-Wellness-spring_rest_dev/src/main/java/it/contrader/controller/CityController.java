package it.contrader.controller;

import it.contrader.dto.CityDTO;
import it.contrader.service.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/cities")
@CrossOrigin(origins = "http://localhost:4200")
public class CityController extends AbstractController<CityDTO>{

    @Autowired
    private CityService service;

    //findByNameLike

    @GetMapping(value = "/findbyname/{name}")
    public ResponseEntity<Iterable<CityDTO>> findByNameLike(@PathVariable("name")String name){
        return new ResponseEntity<Iterable<CityDTO>>(service.findByNameContaining(name), HttpStatus.OK);
    }
}
