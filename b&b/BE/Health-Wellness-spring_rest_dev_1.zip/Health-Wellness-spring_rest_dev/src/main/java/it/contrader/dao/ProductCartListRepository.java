package it.contrader.dao;

import it.contrader.model.Product;
import it.contrader.model.ProductCartList;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface ProductCartListRepository  extends CrudRepository<ProductCartList, Long> {


    public boolean existsByCartIdAndProductId(long cartId, long productId);

    public ProductCartList findByCartIdAndProductId(long cartId, long productId);

    public List<ProductCartList> findAllByCart(long cartId);


}
