package it.contrader.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name="payment_type")
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = PaymentType.class)
public class PaymentType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String data;

    @OneToMany(mappedBy = "paymentType", cascade = CascadeType.MERGE)
    private List<Order> orders;

    public PaymentType(Long id, String name, String data) {
        this.id = id;
        this.name = name;
        this.data = data;
    }
}
