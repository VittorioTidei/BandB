package it.contrader.converter;

import it.contrader.dto.TreatmentDTO;
import it.contrader.model.Treatment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TreatmentConverter extends AbstractConverter<Treatment, TreatmentDTO> {

    @Autowired
    ProductConverter productConverter;

    @Autowired
    CategoryConverter categoryConverter;

    @Override
    public Treatment toEntity(TreatmentDTO treatmentDTO){
        Treatment treatment = null;
        if(treatmentDTO != null)
            treatment = new Treatment(treatmentDTO.getId(),treatmentDTO.getName(), treatmentDTO.getDescription(),productConverter.toEntityList(treatmentDTO.getProducts()), categoryConverter.toEntity(treatmentDTO.getCategory()));

        return treatment;
    }

    public Treatment toEntityLazy(TreatmentDTO treatmentDTO){
        Treatment treatment = null;
        if(treatmentDTO != null)
            treatment = new Treatment(treatmentDTO.getId(),treatmentDTO.getName(), treatmentDTO.getDescription(), categoryConverter.toEntity(treatmentDTO.getCategory()));

        return treatment;
    }

    @Override
    public TreatmentDTO toDTO(Treatment treatment){
        TreatmentDTO treatmentDTO = null;
        if(treatment != null)
            treatmentDTO = new TreatmentDTO(treatment.getId(),treatment.getName(), treatment.getDescription(),productConverter.toDTOList(treatment.getProducts()),categoryConverter.toDTO(treatment.getCategory()));

        return treatmentDTO;
    }


    public TreatmentDTO toDTOLazy(Treatment treatment){
        TreatmentDTO treatmentDTO = null;
        if(treatment != null)
            treatmentDTO = new TreatmentDTO(treatment.getId(),treatment.getName(), treatment.getDescription(),categoryConverter.toDTO(treatment.getCategory()));

        return treatmentDTO;
    }

}
