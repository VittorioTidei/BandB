package it.contrader.controller;

import it.contrader.dto.CartDTO;
import it.contrader.service.AvatarService;
import it.contrader.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import it.contrader.dto.LoginDTO;
import it.contrader.dto.UserDTO;
import it.contrader.service.UserService;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.IOException;

/**
 * 
 * Questa classe estende AbstractController con tipo UserDTO.
 * In aggiunta ai metodi di CRUD si implementa il metodo di login.
 * 
 * @author Vittorio Valent & Girolamo Murdaca
 * 
 * @param<UserDTO>
 * 
 * @see AbstractController
 *
 */
@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController extends AbstractController<UserDTO>{
	
	@Autowired
	private UserService userService;

	@Autowired
	private CartService cartService;

	@Autowired
	private AvatarService avatarService;

	@Value("${avatar.size}")
	private long size;

	@Value("${avatar.height}")
	private int height;

	@Value("${avatar.width}")
	private int width;

	@Value("${avatar.extensions}")
	private String[] extensions;


	//POST Angular a UserDTO
	@PostMapping(value = "/login")
	public ResponseEntity<?> login(@RequestBody LoginDTO loginDTO) throws IOException {

		if((userService.findByUsernameAndPassword(loginDTO.getUsername(), loginDTO.getPassword())) != null){
			UserDTO userDTO = userService.findByUsernameAndPassword(loginDTO.getUsername(), loginDTO.getPassword());
			if(!cartService.existsByUserId(userDTO.getId())){
				CartDTO cartDTO = new CartDTO();
				//cartDTO.setCreatedAt(LocalDate.now());
				//cartDTO.setUpdatedAt(LocalDate.now());
				cartDTO.setUser(userDTO);
				cartService.insert(cartDTO);
			}
			return ResponseEntity.status(HttpStatus.OK).body(userService.findByUsernameAndPassword(loginDTO.getUsername(), loginDTO.getPassword()));
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Utente non trovato");
	}

	@GetMapping(value = "/list")
	public ResponseEntity<Iterable<UserDTO>> getAll(){

		return new ResponseEntity<Iterable<UserDTO>>(userService.getAll(), HttpStatus.OK);
	}

	@PutMapping(value = "/uploadimg",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@Transactional
	public ResponseEntity<?> uploadImage(
			@RequestParam("id") long userId,
			@RequestParam MultipartFile file) throws IOException {

		// check extensions
		if(!avatarService.checkExtension(file, extensions))
			return new ResponseEntity<String>("File type not allowed", HttpStatus.FORBIDDEN);

		// check size (bytes)
		if(!avatarService.checkSize(file, size))
			return new ResponseEntity<String>("Avatar too big or empty", HttpStatus.FORBIDDEN);

		// check dimensions
		if(!avatarService.checkDimensions(avatarService.fromMultipartFileToBufferedImage(file), width, height))
			return new ResponseEntity<String>("Wrong Avatar size", HttpStatus.FORBIDDEN);


		String src = avatarService.getBase64FromFile(file);
		UserDTO u = userService.read(userId);
		u.setAvatar(src);
		userService.update(u);

		return new ResponseEntity<String>(u.getAvatar(), HttpStatus.OK);
	}


}

/**
 * Partendo da controller faccio update avatar con richiesta PUT con endpoint da fare a parte;
 *
 */