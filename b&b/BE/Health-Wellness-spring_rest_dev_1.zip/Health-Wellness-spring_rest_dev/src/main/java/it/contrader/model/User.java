package it.contrader.model;

import javax.persistence.Entity;

import javax.persistence.*;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.time.LocalDate;
import java.util.Base64;
import java.util.List;

/*
 * 
 * Model dell'entità User. Contiene l'enum che definisce gli usertype (salvati come interi
 * a partire da 0 sul db).
 * 
 * @author Vittorio Valent & Girolamo Murdaca
 * 
 * @see UserDTO
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "users")
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = User.class)
public class User {

	public enum Usertype {
		SUPERADMIN, ADMIN, USER
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String username;

	private String password;

	private Usertype usertype;

	private String firstname;

	private String lastname;

	private String address;

	private String zipcode;

	private String email;

	private String phone;

	private LocalDate birthdayDate;

	@Lob
	@Column(length = 10000)
	private String avatar;

	@ManyToOne
	@JoinColumn(name = "city_id")
	@JsonManagedReference
	private City city;

	@OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
	@JsonBackReference
	@JsonIgnore
	private List<Center> centers;

	@OneToMany(mappedBy = "user", cascade = CascadeType.REFRESH)
	@JsonBackReference
	@JsonIgnore
	private List<Order> orders;

	@OneToMany(mappedBy = "user")
	@JsonBackReference
	@JsonIgnore
	private List<Cart> carts;

	public User(String username, String password, Usertype usertype, String firstname, String lastname, String address, String zipcode, String email, String phone, LocalDate birthdayDate, City city) {
		this.username = username;
		this.password = password;
		this.usertype = usertype;
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.zipcode = zipcode;
		this.email = email;
		this.phone = phone;
		this.birthdayDate = birthdayDate;
		this.city = city;
	}

	public User(Long id, String username, String password, Usertype usertype, String firstname, String lastname, String address, String zipcode, String email, String phone, LocalDate birthdayDate, City city) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.usertype = usertype;
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.zipcode = zipcode;
		this.email = email;
		this.phone = phone;
		this.birthdayDate = birthdayDate;
		this.city = city;
	}



}
