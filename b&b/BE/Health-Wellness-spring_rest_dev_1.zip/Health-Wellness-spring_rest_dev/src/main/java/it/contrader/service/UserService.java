package it.contrader.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import it.contrader.dao.UserRepository;
import it.contrader.dto.UserDTO;
import it.contrader.model.User;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * Estende AbstractService con parametri User e UserDTO. 
 * Implementa il metodo di login ed eredita quelli Abstract. 
 * 
 * @author Vittorio Valent & Girolamo Murdaca
 * 
 * @see AbstractService
 * @see ServiceDTO
 */
@Service
public class UserService extends AbstractService<User,UserDTO> {


	//ALL crud methods in AbstractService
	
	//LOGIN method
	public UserDTO findByUsernameAndPassword(String username, String password) {
		return converter.toDTO(((UserRepository)repository).findByUsernameAndPassword(username, password));
	}

	public boolean existByUsernameAndPassword(String username, String password) {
		return ((UserRepository)repository).existsByUsernameAndPassword(username, password);
	}
	/*
	public List<UserDTO> getAdminUsersList() {
		return converter.toDTOList((UserRepository)repository.findByUsertype(User.Usertype.ADMIN));
	}
	 */


	@Override
	public Iterable<UserDTO> getAll() {
		return converter.toDTOList(((UserRepository)repository).findByUsertypeNot(User.Usertype.SUPERADMIN));
	}

	public byte[] convertToByteArray(MultipartFile file) throws IOException {
		byte [] byteArr = null;
		if(file != null){
			byteArr = file.getBytes();
			return byteArr;
		}
		return null;
	}

	public MultipartFile convertToMultipartFile(byte[] byteArr) throws IOException {
		MultipartFile file = null;
		if(byteArr != null){
			file.getInputStream();
			return file;
		}
		return null;
	}


}

/*
public class UserService extends AbstractService<User, UserDTO> {

	@Autowired
	private UserConverter converter;
	@Autowired
	private UserRepository repository;

	public UserDTO findByUsernameAndPassword(String username, String password) {
		return converter.toDTO(repository.findByUsernameAndPassword(username, password));
	}

	public List<UserDTO> getAdminUsersList() {
		return converter.toDTOList(repository.findByUsertype(User.Usertype.ADMIN));
	}

	public Boolean isAdmin(UserDTO user){
		//test output
		return user.getUsertype().equals(User.Usertype.ADMIN);
	}
	public Boolean isSuperadmin(UserDTO user){
		//test output
		return user.getUsertype().equals(User.Usertype.SUPERADMIN);
	}
	@Override
	public List<UserDTO> getAll() {
		return converter.toDTOList(repository.findByUsertypeNot(User.Usertype.SUPERADMIN));
	}
}
 */
