package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import it.contrader.model.*;
import jxl.write.DateTime;
import lombok.*;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = ProductOrderListDTO.class)
public class ProductOrderListDTO {

    private Long id;
    private String name;
    private String description;
    private float price;
    private float discount;
    private LocalDate startDiscountDate;
    private LocalDate endDiscountDate;

    private boolean deleted;

    private LocalDate createdAt;

    private LocalDate updatedAt;
    private int qty;

    private float pricePurchase;

    private String imagePath;

    private CenterDTO center;
    private OrderDTO order;
    private ProductDTO product;

    public ProductOrderListDTO(Long id, String name, String description, float price, float discount, LocalDate startDiscountDate, LocalDate endDiscountDate, int qty, float pricePurchase,String imagePath, CenterDTO center, OrderDTO order, ProductDTO product) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.qty = qty;
        this.pricePurchase = pricePurchase;
        this.imagePath = imagePath;
        this.center = center;
        this.order = order;
        this.product = product;
    }

    public ProductOrderListDTO( String name, String description, float price, float discount, LocalDate startDiscountDate, LocalDate endDiscountDate, int qty, float pricePurchase,String imagePath, CenterDTO center, OrderDTO order, ProductDTO product) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.qty = qty;
        this.pricePurchase = pricePurchase;
        this.imagePath = imagePath;
        this.center = center;
        this.order = order;
        this.product = product;
    }

    public ProductOrderListDTO(Long id, String name, String description, float price, float discount, LocalDate startDiscountDate, LocalDate endDiscountDate, int qty, float pricePurchase,String imagePath) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.qty = qty;
        this.pricePurchase = pricePurchase;
        this.imagePath = imagePath;
    }
}
