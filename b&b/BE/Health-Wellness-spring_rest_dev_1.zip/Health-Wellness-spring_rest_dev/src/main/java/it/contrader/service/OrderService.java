package it.contrader.service;

import it.contrader.converter.OrderConverter;
import it.contrader.dao.OrderRepository;
import it.contrader.dto.OrderDTO;
import it.contrader.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService extends AbstractService<Order, OrderDTO> {

    @Autowired
    OrderConverter orderConverter;

    public Iterable<OrderDTO> getAllByUserId(long id){
        return converter.toDTOList(((OrderRepository)repository).getAllByUserId(id));
    }

    /* public Iterable<OrderDTO> getAllByCenterId(long id){
        return converter.toDTOList(((OrderRepository)repository).getAllByCenterId(id));
    }*/
}
