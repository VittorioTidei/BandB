package it.contrader.converter;

import it.contrader.dto.OrderDTO;
import it.contrader.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderConverter extends AbstractConverter <Order, OrderDTO> {

    @Autowired
    private UserConverter userConverter;
    @Autowired
    private CartConverter cartConverter;
    @Autowired
    private PaymentTypeConverter paymentTypeConverter;

    @Autowired
    private ProductOrderListConverter productOrderListConverter;

    @Autowired
    private CenterConverter centerConverter;

    @Override
    public Order toEntity(OrderDTO orderDTO) {
        Order order = null;
        if (orderDTO != null) {
            order = new Order(orderDTO.getId(), orderDTO.getTotalPrice(), userConverter.toEntityLazy(orderDTO.getUser()),cartConverter.toEntityLazy(orderDTO.getCart()),paymentTypeConverter.toEntity(orderDTO.getPaymentType()), productOrderListConverter.toEntityList(orderDTO.getProductsOrderList()) );
        }
        return order;
    }

    public Order toEntityLazy(OrderDTO orderDTO) {
        Order order = null;
        if (orderDTO != null) {
            order = new Order(orderDTO.getId(), orderDTO.getTotalPrice() );
        }
        return order;
    }

    @Override
    public OrderDTO toDTO(Order order) {
        OrderDTO orderDTO = null;
        if (order != null) {
            orderDTO = new OrderDTO(order.getId(), order.getTotalPrice(), userConverter.toDTOLazy(order.getUser()),cartConverter.toDTOLazy(order.getCart()),paymentTypeConverter.toDTO(order.getPaymentType()),productOrderListConverter.toDTOList(order.getProductsOrderList()) );
        }
        return orderDTO;
    }

    public OrderDTO toDTOLazy(Order order) {
        OrderDTO orderDTO = null;
        if (order != null) {
            orderDTO = new OrderDTO(order.getId(), order.getTotalPrice() );
        }
        return orderDTO;
    }

}
