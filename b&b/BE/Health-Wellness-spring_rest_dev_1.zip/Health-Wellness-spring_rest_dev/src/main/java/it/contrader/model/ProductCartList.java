package it.contrader.model;


import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jxl.write.DateTime;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "products_cart_list")
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = ProductCartList.class)
public class ProductCartList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate createdAt;

    private LocalDate updatedAt;

    private int qty;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cart_id")
    @JsonManagedReference
    @JsonIgnore
    private Cart cart;


    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
    @JoinColumn(name = "product_id")
    @JsonManagedReference
    private Product product;

    public ProductCartList(int qty, Cart cart, Product product) {
        this.qty = qty;
        this.cart = cart;
        this.product = product;
    }

    public ProductCartList(Long id, int qty, Product product) {
        this.id = id;
        this.qty = qty;
        this.product = product;
    }

    @PrePersist
    private void onCreate(){
        this.createdAt = LocalDate.now();
        this.updatedAt = LocalDate.now();
    }

    @PreUpdate
    private void onUpdate(){
        this.updatedAt = LocalDate.now();
    }

    public ProductCartList(Long id, int qty,Cart cart, Product product) {
        this.id = id;
        this.qty = qty;
        this.cart = cart;
        this.product = product;
    }
}
