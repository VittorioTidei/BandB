package it.contrader.service;

import it.contrader.util.AvatarUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Iterator;
import java.util.Optional;


@Service
public class AvatarService{

    public boolean checkSize(MultipartFile file, long size){
        return !file.isEmpty() && file.getSize() <= size;
    }

    public BufferedImage fromMultipartFileToBufferedImage(MultipartFile file){
        BufferedImage bf = null;
        try{
            bf = ImageIO.read(file.getInputStream());
            return bf;
        } catch (IOException e){
            return null;
        }
    }

    public boolean checkDimensions(BufferedImage bf, int width, int height){
        if(bf == null)
            return false;

        return bf.getWidth() <= width && bf.getHeight() <= height;
    }

    public boolean checkExtension(MultipartFile file, String[] extensions) {
        ImageInputStream img = null;
        try {
            img = ImageIO.createImageInputStream(file.getInputStream());
        } catch (IOException e) {
            return false;
        }

        Iterator<ImageReader> imageReaders = ImageIO.getImageReaders(img);

        while (imageReaders.hasNext()) {
            ImageReader reader = imageReaders.next();
            try {
                for (int i = 0; i < extensions.length; i++) {
                    if (reader.getFormatName().equalsIgnoreCase(extensions[i])) {
                        return true;
                    }
                }
            } catch (IOException e) {
                return false;
            }
        }
        return false;
    }

    public String getExtension(MultipartFile file) {
        ImageInputStream img = null;
        try {
            img = ImageIO.createImageInputStream(file.getInputStream());
        } catch (IOException e) {
            return e.toString();
        }

        Iterator<ImageReader> imageReaders = ImageIO.getImageReaders(img);

        while (imageReaders.hasNext()) {
            ImageReader reader = imageReaders.next();
            try {
                return reader.getFormatName();

            } catch (IOException e) {
                return e.toString();
            }
        }
        return "Error";
    }

    public String getBase64FromFile(MultipartFile file) throws IOException{
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(this.fromMultipartFileToBufferedImage(file), this.getExtension(file), out);
        byte[] bytes = out.toByteArray();

        String encodedString = Base64.getEncoder().encodeToString(bytes);
        String src = "data:" + file.getContentType() + ";base64," + encodedString;
        return src;
    }




    // file gae




}
