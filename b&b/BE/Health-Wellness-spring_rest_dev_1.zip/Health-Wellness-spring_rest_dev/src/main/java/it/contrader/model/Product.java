package it.contrader.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "products")
@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = Product.class)
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column (name = "title")
    private String title;

    @Column (name = "description")
    private String description;

    @Column (name = "price")
    private float price;

    private float discount;

    @Column (name = "quantity")
    private int qty;

    private LocalDate startDiscountDate;

    private LocalDate endDiscountDate;

    private String imagePath;

    @Column (name = "deleted")
    private boolean deleted = false;


    @Column (name = "created_at", updatable = false)
    private LocalDate createdAt;

    @Column (name = "updated_at", updatable = false, insertable = false)
    private LocalDate updatedAt;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "center_id")
    @JsonManagedReference
    private Center center;

    @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
    @JoinColumn(name ="treatment_id")
    @JsonManagedReference
    private Treatment treatment;


    public Product(long id,  String title,  String description, float price, float discount, int qty, LocalDate startDiscountDate, LocalDate endDiscountDate, Center center, Treatment treatment) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.qty = qty;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.center = center;
        this.treatment = treatment;
    }

    public Product(String title, String description, float price, float discount, int qty, LocalDate startDiscountDate, LocalDate endDiscountDate, String imagePath, Center center, Treatment treatment) {
        this.title = title;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.qty = qty;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.imagePath = imagePath;
        this.center = center;
        this.treatment = treatment;
    }

    public Product(Long id, String title, String description, float price, float discount, int qty, LocalDate startDiscountDate, LocalDate endDiscountDate, Treatment treatment) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.qty = qty;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.treatment = treatment;
    }
}
