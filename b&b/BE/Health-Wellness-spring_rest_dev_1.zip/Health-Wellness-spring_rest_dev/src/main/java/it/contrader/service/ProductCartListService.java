package it.contrader.service;

import it.contrader.dao.CartRepository;
import it.contrader.dao.ProductCartListRepository;
import it.contrader.dto.ProductCartListDTO;
import it.contrader.model.ProductCartList;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductCartListService extends  AbstractService<ProductCartList, ProductCartListDTO> {


    public boolean existsByCartIdAndProductId(long cartId, long productId) {
        return ((ProductCartListRepository) repository).existsByCartIdAndProductId(cartId, productId);
    }

    public ProductCartListDTO findByCartIdAndProductId(long cartId, long productId) {
        return converter.toDTO(((ProductCartListRepository) repository).findByCartIdAndProductId(cartId, productId));
    }
    public List<ProductCartListDTO> getAllByCartId(long id) {
        return converter.toDTOList((List<ProductCartList>) ((ProductCartListRepository) repository).findAllByCart(id));
    }
}