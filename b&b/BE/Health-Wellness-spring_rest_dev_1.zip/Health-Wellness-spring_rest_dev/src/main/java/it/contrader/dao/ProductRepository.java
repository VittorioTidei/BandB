package it.contrader.dao;

import it.contrader.model.Product;
import it.contrader.model.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface ProductRepository extends CrudRepository<Product, Long> {

    List<Product> getAllByCenterId(long id);

    @Query(value = "SELECT p FROM Product p LEFT JOIN Center c ON p.center = c LEFT JOIN User u ON c.user = u WHERE c.user.id <> :id AND p.deleted = false")
    List<Product> getAllByAdminIdNot(long id);

    @Query("UPDATE ProductCartList p SET p.qty = :qty WHERE p = :prod")
    Product updateProductInCart(@Param("prod") Product product, @Param("qty") int qty);


    @Query("DELETE FROM ProductCartList p WHERE p.id = :id")
    void deleteProductByCart(@Param("id") long id);
}
