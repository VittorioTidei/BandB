package it.contrader.dao;

import it.contrader.model.City;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CityRepository  extends CrudRepository<City, Long> {

    public Iterable<City> findByNameContaining(String name);
}
