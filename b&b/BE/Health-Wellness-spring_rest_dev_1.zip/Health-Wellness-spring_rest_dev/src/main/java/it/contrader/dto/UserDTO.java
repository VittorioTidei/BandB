package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import it.contrader.model.Center;
import it.contrader.model.City;
import it.contrader.model.Order;
import it.contrader.model.Treatment;
import it.contrader.model.User.Usertype;
import jxl.write.DateTime;
import lombok.*;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.ConstructorResult;
import javax.persistence.Lob;
import java.beans.ConstructorProperties;
import java.io.ByteArrayInputStream;
import java.time.LocalDate;
import java.util.Base64;
import java.util.List;

/*
 * DTO della classe User. Ha gli stessi attributi di User
 * 
 * @author Vittorio Valent & Girolamo Murdaca
 * 
 *@see User
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = UserDTO.class)
public class UserDTO {

	private Long id;

	private String username;

	private String password;

	private Usertype usertype;

	private String firstname;

	private String lastname;

	private String address;

	private String zipcode;

	private String email;

	private String phone;

	private LocalDate birthdayDate;

	private String avatar;

	private CityDTO city;

	private List<CenterDTO> centers;

	private List<OrderDTO> orders;

	private List<CartDTO> carts;

	public UserDTO(Long id, String username, String password, Usertype usertype, String firstname, String lastname, String address, String zipcode, String email, String phone, LocalDate birthdayDate, CityDTO city) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.usertype = usertype;
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.zipcode = zipcode;
		this.email = email;
		this.phone = phone;
		this.birthdayDate = birthdayDate;
		this.city = city;
	}

	public UserDTO(String username, String password, Usertype usertype, String firstname, String lastname, String address, String zipcode, String email, String phone, LocalDate birthdayDate, CityDTO city) {
		this.username = username;
		this.password = password;
		this.usertype = usertype;
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.zipcode = zipcode;
		this.email = email;
		this.phone = phone;
		this.birthdayDate = birthdayDate;
		this.city = city;
	}

	public UserDTO(Long id, String firstname, String lastname, String address, String zipcode, String email, String phone, LocalDate birthdayDate, CityDTO city) {
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.zipcode = zipcode;
		this.email = email;
		this.phone = phone;
		this.birthdayDate = birthdayDate;
		this.city = city;
	}

	/*
	public Boolean isAdmin(UserDTO user){
		//test output
		return user.getUsertype().equals(Usertype.ADMIN);
	}
	public Boolean isSuperadmin(UserDTO user){
		//test output
		return user.getUsertype().equals(Usertype.SUPERADMIN);
	}
	 */

}
