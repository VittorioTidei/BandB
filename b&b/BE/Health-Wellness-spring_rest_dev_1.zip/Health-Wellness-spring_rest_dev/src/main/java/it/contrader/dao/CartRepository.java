package it.contrader.dao;

import it.contrader.model.Cart;
import it.contrader.model.ProductCartList;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface CartRepository extends CrudRepository<Cart, Long> {

    public boolean existsByUserId(long id);

    public Cart findByUserId(long id);

    @Query(value="SELECT c FROM Cart c WHERE c.id NOT IN (SELECT o.cart.id FROM Order o)")
    public List<Cart> cartIsActive(long id);
    /*
        @Query(value="SELECT c FROM Cart c WHERE c.user.id = :id AND c.id NOT IN (SELECT o.cart.id FROM Order o)")
        public Cart hasActiveCart(long id);


         @Query(value="SELECT c FROM Cart c WHERE c.user.id = :id AND c.id NOT IN (SELECT o.cart.id FROM Order o)")
         public Cart readCartByUser(long id);
    */

}
