package it.contrader.service;
import org.springframework.stereotype.Service;
import it.contrader.dto.PaymentTypeDTO;
import it.contrader.model.PaymentType;
@Service
public class PaymentTypeService extends AbstractService<PaymentType, PaymentTypeDTO> {
}
