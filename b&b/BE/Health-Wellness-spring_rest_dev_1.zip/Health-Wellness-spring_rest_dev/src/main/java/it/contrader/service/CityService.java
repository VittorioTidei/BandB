package it.contrader.service;

import it.contrader.dao.CityRepository;
import it.contrader.dto.CityDTO;
import it.contrader.model.City;
import org.springframework.stereotype.Service;

@Service
public class CityService extends AbstractService<City, CityDTO> {

    public Iterable<CityDTO> findByNameContaining(String name){
        return converter.toDTOList(((CityRepository)repository).findByNameContaining(name));
    }
}
