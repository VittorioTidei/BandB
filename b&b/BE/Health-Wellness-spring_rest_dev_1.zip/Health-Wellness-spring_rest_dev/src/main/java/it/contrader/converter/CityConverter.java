package it.contrader.converter;

import it.contrader.dto.CityDTO;
import it.contrader.model.City;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CityConverter extends AbstractConverter<City, CityDTO> {

    @Override
    public City toEntity(CityDTO cityDTO){
        City city = null;
        if(cityDTO != null)
            city = new City(cityDTO.getId(),cityDTO.getName(), cityDTO.getProvince());
        return city;
    }

    @Override
    public CityDTO toDTO(City city){
        CityDTO cityDTO = null;
        if(city != null)
            cityDTO = new CityDTO(city.getId(), city.getName(), city.getProvince());

        return cityDTO;
    }
}
