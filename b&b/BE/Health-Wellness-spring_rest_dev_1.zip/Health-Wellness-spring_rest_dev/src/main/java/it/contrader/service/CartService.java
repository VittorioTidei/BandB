package it.contrader.service;

import it.contrader.converter.ProductCartListConverter;
import it.contrader.dao.CartRepository;
import it.contrader.dto.CartDTO;
import it.contrader.dto.ProductCartListDTO;
import it.contrader.dto.UserDTO;
import it.contrader.model.Cart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartService extends AbstractService<Cart, CartDTO>{

    @Autowired
    private ProductCartListConverter productCartListConverter;
    public boolean existsByUserId(long id){
        return ((CartRepository)repository).existsByUserId(id);
    }

    public CartDTO findByUserId(long id){
        return converter.toDTO(((CartRepository)repository).findByUserId(id));
    }

    public boolean cartIsActive(long id) {
        boolean cartIsActive = ((CartRepository)repository).cartIsActive(id).size() > 0;
        return cartIsActive;
    }




/*
    public boolean hasActiveCart(long id) {
        if(((CartRepository)repository).hasActiveCart(id) != null)
            return true;

        return false;
    }

    public CartDTO readCartByUser(long id){
        return converter.toDTO(((CartRepository)repository).readCartByUser(id));
    }
    */

}
