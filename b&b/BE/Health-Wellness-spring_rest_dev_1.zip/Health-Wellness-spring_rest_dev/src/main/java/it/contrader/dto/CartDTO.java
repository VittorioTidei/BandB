package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import it.contrader.model.Order;
import it.contrader.model.ProductCartList;
import it.contrader.model.Treatment;
import it.contrader.model.User;
import jxl.write.DateTime;
import lombok.*;

import javax.persistence.OneToOne;
import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = CartDTO.class)
public class CartDTO {

    private Long id;

    private LocalDate createdAt;

    private LocalDate updatedAt;

    private UserDTO user;

    private List<ProductCartListDTO> productsCartList;

    public CartDTO(Long id, UserDTO user, List<ProductCartListDTO> productsCartList) {
        this.id = id;
        this.user = user;
        this.productsCartList = productsCartList;
    }

    public CartDTO(UserDTO user, List<ProductCartListDTO> productsCartList) {
        this.user = user;
        this.productsCartList = productsCartList;
    }

    public CartDTO(Long id, UserDTO user) {
        this.id = id;
        this.user = user;
    }
    public CartDTO(Long id) {
        this.id = id;
    }
}
