package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import it.contrader.model.Category;
import it.contrader.model.Product;
import it.contrader.model.Treatment;
import lombok.*;

import javax.persistence.OneToMany;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = TreatmentDTO.class)
public class TreatmentDTO {

    private Long id;

    private String name;

    private String description;

    private List<ProductDTO> products;

    private CategoryDTO category;

    public TreatmentDTO(Long id, String name, String description, CategoryDTO category) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public TreatmentDTO(String name, String description, CategoryDTO category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }
}
