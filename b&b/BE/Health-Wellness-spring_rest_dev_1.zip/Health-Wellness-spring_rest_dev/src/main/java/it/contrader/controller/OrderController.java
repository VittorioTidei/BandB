package it.contrader.controller;

import it.contrader.dto.*;
import it.contrader.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping("/orders")
@CrossOrigin(origins = "http://localhost:4200")
public class OrderController extends AbstractController<OrderDTO>{

    @Autowired
    private OrderService orderService;

    @Autowired
    private ProductCartListService productCartListService;

    @Autowired
    private ProductOrderListService productOrderListService;
    @Autowired
    private PaymentTypeService paymentTypeService;

    @Autowired
    private CenterService centerService;

    @Autowired
    private UserService userService;
    @Autowired
    private CartService cartService;

    @GetMapping(value = "/getall/user/{id}")
    public ResponseEntity<Iterable<OrderDTO>> getAllByUserId(@PathVariable("id")long id){
        return new ResponseEntity<Iterable<OrderDTO>>(orderService.getAllByUserId(id), HttpStatus.OK);
    }

    @GetMapping(value = "/getall/productorderlist/{id}")
    public ResponseEntity<Iterable<ProductOrderListDTO>> getProductOrderListById(@PathVariable("id") long id){
        return new ResponseEntity<Iterable<ProductOrderListDTO>>(productOrderListService.getAllByOrderId(id),HttpStatus.OK);
    }

/*
    @GetMapping(value = "/getall/center/{id}")
    public ResponseEntity<Iterable<OrderDTO>> getAllByCenterId(@PathVariable("id")long id){
        return new ResponseEntity<Iterable<OrderDTO>>(orderService.getAllByCenterId(id), HttpStatus.OK);
    }
*/

    @PostMapping(value = "/convert")
    public ResponseEntity<?> insert(
            @RequestParam long userId,
            @RequestParam long centerId,
            @RequestParam long paymentId,
            @RequestParam long cartId ){
        try{
            if (cartService.cartIsActive(cartId)) {
                CartDTO cartDTO = cartService.read(cartId);
                // inizializzare il nuovo oggetto order
                OrderDTO orderDTO = new OrderDTO();
                List<ProductOrderListDTO> productsOrderListDTO = new ArrayList<ProductOrderListDTO>();
                CenterDTO centerDTO = centerService.read(centerId);

                // Verifica quantità rimaste e quantità da acquistare
                // Totale productCartList.product.price * productCartList.qty
                // Calcolo totale ordine
                List<ProductCartListDTO> productCartListElements = cartDTO.getProductsCartList();

                // Con uno stream MAP mappo i prodotti sommandone il prezzo con la quantità e ritornando un valore unico per prodotto
                // Con lo stream REDUCE vado a accorpare i price dei singoli prodotti gestiti con il MAP nel prezzo totale
                float totalPrice = productCartListElements
                        .stream()
                        .map(productCartListElement -> {
                            // Aggiungo elementi alla lista "ProductOrderList"
                            ProductOrderListDTO productOrderListDTO = new ProductOrderListDTO();

                            productOrderListDTO.setName(productCartListElement.getProduct().getTitle());
                            productOrderListDTO.setDescription(productCartListElement.getProduct().getDescription());
                            productOrderListDTO.setPrice(productCartListElement.getProduct().getPrice());
                            productOrderListDTO.setDiscount(productCartListElement.getProduct().getDiscount());
                            productOrderListDTO.setStartDiscountDate(productCartListElement.getProduct().getStartDiscountDate());
                            productOrderListDTO.setEndDiscountDate(productCartListElement.getProduct().getEndDiscountDate());
                            productOrderListDTO.setDeleted(productCartListElement.getProduct().isDeleted());
                            productOrderListDTO.setCenter(productCartListElement.getProduct().getCenter());
                            productOrderListDTO.setProduct(productCartListElement.getProduct());


                            //Calcolo totale prodotto in base alla data odierna e alla qty in carrello se incluso nei limiti di date
                            LocalDate min = productCartListElement.getProduct().getStartDiscountDate();
                            LocalDate max = productCartListElement.getProduct().getEndDiscountDate();
                            LocalDate now = LocalDate.now();
                            float pricePurchase = 0.0f;
                            if ((now.isAfter(min) && now.isBefore(max)) || now.isEqual(max) || now.isEqual(min)) {
                                pricePurchase = productCartListElement.getProduct().getDiscount() * productCartListElement.getQty();
                            } else {
                                pricePurchase = productCartListElement.getProduct().getPrice() * productCartListElement.getQty();
                            }

                            productOrderListDTO.setPricePurchase(pricePurchase);
                            productsOrderListDTO.add(productOrderListDTO);
                            return pricePurchase;
                        })
                        .reduce(0.0f, (total, totalProduct) -> total + totalProduct);

                orderDTO.setTotalPrice(totalPrice);
                orderDTO.setPaymentType(paymentTypeService.read(paymentId));
                orderDTO.setCart(cartDTO);
                orderDTO.setUser(userService.read(userId));
                OrderDTO returnOrder = orderService.insert(orderDTO);

                List<ProductOrderListDTO> productsList = productsOrderListDTO
                        .stream()
                        .map(e -> {
                            e.setOrder(returnOrder);
                            return e;
                        }).collect(Collectors.toList());

                productOrderListService.insertAll((Iterable)productsOrderListDTO);

//                productsOrderListDTO.forEach( item -> {
//                    item.setOrder(returnOrder);
//                    productOrderListService.insert(item);
//                });

                return new ResponseEntity<OrderDTO>(orderService.read(returnOrder.getId()),HttpStatus.OK);
            } else {
                return new ResponseEntity<String>("Attenzione! Il carrello risulta già convertito in ordine", HttpStatus.OK);
            }
        }catch(IllegalArgumentException ex){
            return new ResponseEntity<String>(ex.toString(), HttpStatus.BAD_REQUEST);
        }
    }
}

