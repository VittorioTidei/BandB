package it.contrader.converter;

import it.contrader.dto.PaymentTypeDTO;
import it.contrader.model.PaymentType;
import org.springframework.stereotype.Component;

@Component
public class PaymentTypeConverter extends AbstractConverter<PaymentType, PaymentTypeDTO>{


    @Override
    public PaymentType toEntity(PaymentTypeDTO paymentTypeDTO){
        PaymentType paymentType  = null;
        if(paymentTypeDTO != null)
            paymentType = new PaymentType(paymentTypeDTO.getId(), paymentTypeDTO.getName(), paymentTypeDTO.getData());
        return paymentType;
    }

    @Override
    public PaymentTypeDTO toDTO(PaymentType paymentType){
        PaymentTypeDTO paymentTypeDTO = null;
        if(paymentType != null)
            paymentTypeDTO = new PaymentTypeDTO(paymentType.getId(), paymentType.getName(), paymentType.getData());

        return paymentTypeDTO;
    }
}
