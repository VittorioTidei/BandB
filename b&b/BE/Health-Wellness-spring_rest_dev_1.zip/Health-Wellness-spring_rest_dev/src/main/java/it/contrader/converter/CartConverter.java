package it.contrader.converter;

import it.contrader.dto.CartDTO;
import it.contrader.model.Cart;
import it.contrader.model.ProductCartList;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

@Component
public class CartConverter extends AbstractConverter <Cart, CartDTO>{

    @Autowired
    UserConverter userConverter;
    @Autowired
    ProductCartListConverter productCartListConverter;

    @Override
    public Cart toEntity(CartDTO cartDTO){
        Cart cart = null;
        if(cartDTO != null)
            cart = new Cart(cartDTO.getId(), userConverter.toEntityLazy(cartDTO.getUser()), productCartListConverter.toEntityList(cartDTO.getProductsCartList()) );

        return cart;
    }

    public Cart toEntityLazy(CartDTO cartDTO){
        Cart cart = null;
        if(cartDTO != null)
            cart = new Cart(cartDTO.getId(), userConverter.toEntityLazy(cartDTO.getUser()) );

        return cart;
    }

    @Override
    public CartDTO toDTO(Cart cart){
        CartDTO cartDTO = null;
        if(cart != null)
            cartDTO = new CartDTO(cart.getId(), userConverter.toDTOLazy(cart.getUser()), productCartListConverter.toDTOList(cart.getProductsCartList()) );

        return cartDTO;
    }

    public CartDTO toDTOLazy(Cart cart){
        CartDTO cartDTO = null;
        if(cart != null)
            cartDTO = new CartDTO(cart.getId());

        return cartDTO;
    }
}
