package it.contrader.service;

import it.contrader.converter.UserConverter;
import it.contrader.dao.ProductCartListRepository;
import it.contrader.dao.ProductRepository;
import it.contrader.dto.ProductCartListDTO;
import it.contrader.dto.ProductDTO;
import it.contrader.dto.UserDTO;
import it.contrader.model.Product;
import it.contrader.model.ProductCartList;
import it.contrader.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService extends AbstractService<Product, ProductDTO>{

    @Autowired
    ProductRepository repository;

    @Autowired
    ProductCartListRepository productCartListRepository;
    public boolean existsById(long id) {
        return repository.existsById(id);
    }

    public Iterable<ProductDTO> getAllByCenterId(long id){

        return converter.toDTOList(repository.getAllByCenterId(id));
    }


    /*
    public ResponseEntity<Iterable<ProductDTO>> getAllByAdminIdNot(long id){

        return new ResponseEntity<Iterable<ProductDTO>>(converter.toDTOList(repository.getAllByAdminIdNot(id)), HttpStatus.OK);
    }*/

    public Iterable<ProductDTO> getAllProductsByAdminNot(long id){

        return  converter.toDTOList(repository.getAllByAdminIdNot(id));

    }

    public ProductDTO updateProductInCart(ProductDTO productDTO, int qty){
        return converter.toDTO(repository.updateProductInCart(converter.toEntity(productDTO), qty));
    }

    public void deleteProductInCart(long id){
        repository.deleteProductByCart(id);
    }
}
