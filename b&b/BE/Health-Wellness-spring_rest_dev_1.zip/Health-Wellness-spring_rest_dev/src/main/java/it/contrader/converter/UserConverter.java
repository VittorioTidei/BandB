package it.contrader.converter;

import it.contrader.dto.CityDTO;
import it.contrader.model.Order;
import it.contrader.service.UserService;
import jxl.biff.ByteArray;
import lombok.ToString;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.contrader.dto.UserDTO;

import it.contrader.model.User;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;

/**
 * Questa classe implementa i metodi di conversione dell'entità User.
 *  
 * @author Vittorio Valent & Girolamo Murdaca
 * 
 *@see AbstractConverter
 *@see Converter
 */
@Component
public class UserConverter extends AbstractConverter<User,UserDTO> {

	@Autowired
	UserService userService;
	@Autowired
	private CenterConverter centerConverter;
	@Autowired
	private OrderConverter orderConverter;
	@Autowired
	private CityConverter cityConverter;

	@Autowired
	private CartConverter cartConverter;


	@Override
	public User toEntity(UserDTO userDTO) {
		User user = null;
		if (userDTO != null)
			user = new User(userDTO.getId(), userDTO.getUsername(), userDTO.getPassword(), userDTO.getUsertype(), userDTO.getFirstname(), userDTO.getLastname(), userDTO.getAddress(), userDTO.getEmail(), userDTO.getZipcode(), userDTO.getPhone(),userDTO.getBirthdayDate(),userDTO.getAvatar() , cityConverter.toEntity(userDTO.getCity()), centerConverter.toEntityList(userDTO.getCenters()), orderConverter.toEntityList(userDTO.getOrders()), cartConverter.toEntityList(userDTO.getCarts()));

		return user;
	}
	public User toEntityLazy(UserDTO userDTO) {
		User user = null;
		if (userDTO != null)
			user = new User(userDTO.getId(), userDTO.getUsername(), userDTO.getPassword(), userDTO.getUsertype(), userDTO.getFirstname(), userDTO.getLastname(), userDTO.getAddress(), userDTO.getZipcode(), userDTO.getEmail(), userDTO.getPhone(), userDTO.getBirthdayDate(), cityConverter.toEntity(userDTO.getCity()) );

		return user;
	}

	@Override
	public UserDTO toDTO(User user) {
		UserDTO userDTO = null;
		if (user != null)
			userDTO = new UserDTO(user.getId(), user.getUsername(), user.getPassword(), user.getUsertype(), user.getFirstname(), user.getLastname(), user.getAddress(), user.getZipcode(), user.getEmail(), user.getPhone(),user.getBirthdayDate(), user.getAvatar(), cityConverter.toDTO(user.getCity()), centerConverter.toDTOList(user.getCenters()), orderConverter.toDTOList(user.getOrders()),cartConverter.toDTOList(user.getCarts()));

		return userDTO;
	}
	public UserDTO toDTOLazy(User user) {
		UserDTO userDTO = null;
		if (user != null)
			userDTO = new UserDTO(user.getId(), user.getFirstname(), user.getLastname(), user.getAddress(), user.getZipcode(), user.getEmail(), user.getPhone(), user.getBirthdayDate(), cityConverter.toDTO(user.getCity()));

		return userDTO;
	}
}