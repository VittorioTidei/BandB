package it.contrader.model;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "centers")
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = Center.class)
public class Center {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String description;

    private String address;

    private String zipcode;

    private String phone;

    private String email;

    private String website;

    private String imagePath;

    @ManyToOne
    @JoinColumn(name = "city_id")
    @JsonManagedReference
    private City city;

    @ManyToOne(cascade = CascadeType.REFRESH)
    @JoinColumn(name = "user_id")
    @JsonManagedReference
    private User user;

    @OneToMany(mappedBy = "center", cascade = CascadeType.MERGE)
    @JsonBackReference
    private List<Product> products;

    public Center(Long id, String name, String description, String address, String zipcode, String phone, String email, String website, String imagePath, City city, User user) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.address = address;
        this.zipcode = zipcode;
        this.phone = phone;
        this.email = email;
        this.website = website;
        this.imagePath = imagePath;
        this.city = city;
        this.user = user;
    }

    public Center(String name, String description, String address, String zipcode, String phone, String email, String website, String imagePath, City city, User user) {
        this.name = name;
        this.description = description;
        this.address = address;
        this.zipcode = zipcode;
        this.phone = phone;
        this.email = email;
        this.website = website;
        this.imagePath = imagePath;
        this.city = city;
        this.user = user;
    }
}
