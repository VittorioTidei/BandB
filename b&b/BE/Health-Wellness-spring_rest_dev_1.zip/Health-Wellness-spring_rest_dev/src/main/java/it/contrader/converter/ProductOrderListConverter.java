package it.contrader.converter;

import it.contrader.dto.ProductOrderListDTO;
import it.contrader.model.Order;
import it.contrader.model.ProductOrderList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.Converter;
import java.util.ArrayList;
import java.util.List;

@Component
public class ProductOrderListConverter extends AbstractConverter<ProductOrderList, ProductOrderListDTO> {

    @Autowired
    CenterConverter centerConverter;

    @Autowired
    OrderConverter orderConverter;

    @Autowired
    ProductConverter productConverter;

    @Override
    public ProductOrderList toEntity(ProductOrderListDTO productOrderListDTO){
        ProductOrderList productOrderList= null;
        if(productOrderListDTO != null)
            productOrderList = new ProductOrderList(productOrderListDTO.getId(),productOrderListDTO.getName(),productOrderListDTO.getDescription(),productOrderListDTO.getPrice(),productOrderListDTO.getDiscount(),productOrderListDTO.getStartDiscountDate(),productOrderListDTO.getEndDiscountDate(),productOrderListDTO.getQty(),productOrderListDTO.getPricePurchase(), productOrderListDTO.getImagePath(), centerConverter.toEntityLazy(productOrderListDTO.getCenter()),orderConverter.toEntityLazy(productOrderListDTO.getOrder()),productConverter.toEntityLazy(productOrderListDTO.getProduct()) );

        return productOrderList;
    }


    @Override
    public ProductOrderListDTO toDTO(ProductOrderList productOrderList){
        ProductOrderListDTO productOrderListDTO= null;
        if(productOrderList != null)
            productOrderListDTO = new ProductOrderListDTO(productOrderList.getId(),productOrderList.getName(),productOrderList.getDescription(),productOrderList.getPrice(),productOrderList.getDiscount(),productOrderList.getStartDiscountDate(),productOrderList.getEndDiscountDate(),productOrderList.getQty(),productOrderList.getPricePurchase(), productOrderList.getImagePath(), centerConverter.toDTOLazy(productOrderList.getCenter()),orderConverter.toDTOLazy(productOrderList.getOrder()),productConverter.toDTOLazy(productOrderList.getProduct()) );

        return productOrderListDTO;
    }

    @Override
    public List<ProductOrderListDTO> toDTOList (Iterable<ProductOrderList> listEntity) {
        List<ProductOrderListDTO> list = new ArrayList<ProductOrderListDTO>();

        if(listEntity != null) {
            for (ProductOrderList entity:listEntity) {
                ProductOrderListDTO dto = this.toDTO(entity);
                list.add(dto);
            }
        }
        return list;
    }



}
