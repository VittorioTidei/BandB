package it.contrader.controller;

import it.contrader.dto.CartDTO;
import it.contrader.dto.ProductCartListDTO;
import it.contrader.dto.ProductDTO;
import it.contrader.model.ProductCartList;
import it.contrader.model.User;
import it.contrader.service.CartService;
import it.contrader.service.ProductCartListService;
import it.contrader.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
@CrossOrigin(origins = "http://localhost:4200")
public class ProductController extends AbstractController<ProductDTO>{

    @Autowired
    private ProductService productService;
    private ProductCartListService productCartListService;
    //metodo per leggere la productcartlist nel database...
    //aggiungere il metodo nel typesctript product.service.ts
    //aggiungere il metodo nel confirm per mostrare la lista dei prodotti...
    @GetMapping("/list/user/cart-{id}")
    public ResponseEntity<List<ProductCartListDTO>> getAllByCartId(@PathVariable() long id){

        return new ResponseEntity<>(productCartListService.getAllByCartId(id), HttpStatus.OK);
    }
    @GetMapping("/list/user/not-{id}")
    public ResponseEntity<List<ProductDTO>> getAllByCenterId(@PathVariable() long id){

        return new ResponseEntity<List<ProductDTO>>((List<ProductDTO>) productService.getAllByCenterId(id), HttpStatus.OK);

    }


     @GetMapping("/list/admin/{id}")
     public ResponseEntity<List<ProductDTO>> getAllByAdminIdNot(@PathVariable() long id){

         return new ResponseEntity<List<ProductDTO>>((List<ProductDTO>) productService.getAllProductsByAdminNot(id),HttpStatus.OK);
     }

}
