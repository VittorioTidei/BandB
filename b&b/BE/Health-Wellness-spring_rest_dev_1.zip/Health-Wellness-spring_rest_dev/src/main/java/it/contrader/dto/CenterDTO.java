package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.*;

import javax.persistence.Transient;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = CenterDTO.class)
public class CenterDTO {

    private Long id;

    private String name;

    private String description;

    private String address;

    private String zipcode;

    private String phone;

    private String email;

    private String website;

    private String imagePath;

    private CityDTO city;

    private UserDTO user;

    private List<ProductDTO> products;


    public CenterDTO(Long id, String name, String description, String address, String zipcode, String phone, String email, String website, String imagePath, CityDTO city, UserDTO userDTOLazy) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.address = address;
        this.zipcode = zipcode;
        this.phone = phone;
        this.email = email;
        this.website = website;
        this.imagePath = imagePath;
        this.city = city;
        this.user = userDTOLazy;
    }

    public CenterDTO(String name, String description, String address, String zipcode, String phone, String email, String website, String imagePath, CityDTO city, UserDTO user, List<ProductDTO> productListDTO) {
        this.name = name;
        this.description = description;
        this.address = address;
        this.zipcode = zipcode;
        this.phone = phone;
        this.email = email;
        this.website = website;
        this.imagePath = imagePath;
        this.city = city;
        this.user = user;
    }
}
