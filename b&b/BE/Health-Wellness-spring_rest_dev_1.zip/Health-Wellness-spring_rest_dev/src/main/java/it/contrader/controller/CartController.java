package it.contrader.controller;


import it.contrader.dto.*;
import it.contrader.model.ProductCartList;
import it.contrader.service.CartService;
import it.contrader.service.ProductCartListService;
import it.contrader.service.ProductService;
import it.contrader.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/carts")
@CrossOrigin(origins = "http://localhost:4200")
public class CartController extends AbstractController<CartDTO>{

    @Autowired
    CartService service;

    @Autowired
    ProductService productService;

    @Autowired
    UserService userService;

    @Autowired
    ProductCartListService productCartListService;

    @GetMapping("/read/{id}")
    @Override
    public ResponseEntity<?> read(@PathVariable("id") long userId){
        if(service.existsByUserId(userId))
            return new ResponseEntity<CartDTO>(service.findByUserId(userId), HttpStatus.OK);

        return new ResponseEntity<String>("Nessuna occorrenza trovata", HttpStatus.NOT_FOUND);
    }

    @PostMapping(value = "/updateproduct/{cart_id}/{product_id}/{qty}")
    public ResponseEntity<?> updateProductInCart(
            @PathVariable("cart_id")long cartId,
            @PathVariable("product_id") long product_id,
            @PathVariable("qty") int qty
    ){
        try{

            ProductDTO productToAdd = productService.read(product_id);
            ProductCartListDTO productCartListDTO;

            if (productCartListService.existsByCartIdAndProductId(cartId, productToAdd.getId())) {
                //Se esiste lo seleziono
                productCartListDTO = productCartListService.findByCartIdAndProductId(cartId, productToAdd.getId());
                productCartListDTO.setQty(qty);
                productCartListService.update(productCartListDTO);
            } else {
                //Se non esiste lo inserisco dentro il carrello
                productCartListDTO = new ProductCartListDTO();
                productCartListDTO.setCart(service.read(cartId));
                productCartListDTO.setProduct(productToAdd);
                productCartListDTO.setCreatedAt(LocalDate.now());
                productCartListDTO.setUpdatedAt(LocalDate.now());
                productCartListDTO.setQty(qty);
                productCartListService.insert(productCartListDTO);
            }

            return new ResponseEntity<CartDTO>(service.read(cartId),HttpStatus.OK);
        }catch(IllegalArgumentException ex){
            return new ResponseEntity<String>(ex.toString(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping(value="deleteproductincart/{id}")
    public ResponseEntity<?> removeProductInCart(@PathVariable("id") long id){

        productCartListService.delete(id);

        return new ResponseEntity<String>("Cancellazione andata a buon fine", HttpStatus.OK);


    }

}
