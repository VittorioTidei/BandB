package it.contrader.controller;

import it.contrader.dto.CenterDTO;
import it.contrader.dto.UserDTO;
import it.contrader.service.CenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/centers")
@CrossOrigin(origins = "http://localhost:4200")
public class CenterController extends AbstractController<CenterDTO>{

    @Autowired
    private CenterService centerService;


    @GetMapping("/getallbyadmin/{id}")
    public ResponseEntity<Iterable<CenterDTO>> getAllByUserId(@PathVariable("id")long id){
        return new ResponseEntity<Iterable<CenterDTO>>(centerService.getAllByUserId(id), HttpStatus.OK);
    }

    @GetMapping("/getallbyadminNot/{id}")
    public ResponseEntity<Iterable<CenterDTO>> getAllByUserIdNot(@PathVariable("id")long id){
        return new ResponseEntity<Iterable<CenterDTO>>(centerService.getAllByUserIdNot(id), HttpStatus.OK);
    }
}


