package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import it.contrader.model.Cart;
import it.contrader.model.Product;
import it.contrader.model.ProductCartList;
import it.contrader.model.Treatment;
import jxl.write.DateTime;
import lombok.*;

import javax.persistence.ManyToOne;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = ProductCartListDTO.class)
public class ProductCartListDTO {


    private Long id;

    private LocalDate createdAt;

    private LocalDate updatedAt;

    private int qty;

    private CartDTO cart;

    private ProductDTO product;


    public ProductCartListDTO(Long id, int qty, CartDTO cart, ProductDTO product) {
        this.id = id;
        this.qty = qty;
        this.cart = cart;
        this.product = product;
    }

    public ProductCartListDTO(int qty, CartDTO cart, ProductDTO product) {
        this.qty = qty;
        this.cart = cart;
        this.product = product;
    }

    public ProductCartListDTO(Long id, int qty, ProductDTO product) {
        this.id = id;
        this.qty = qty;
        this.product = product;
    }


}
