package it.contrader.converter;
import it.contrader.dto.CenterDTO;
import it.contrader.model.Center;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CenterConverter extends AbstractConverter <Center, CenterDTO> {

    @Autowired
    private UserConverter userConverter;
    @Autowired
    private ProductConverter productConverter;
    @Autowired
    private CityConverter cityConverter;

    @Autowired
    private OrderConverter orderConverter;

    @Override
    public Center toEntity(CenterDTO centerDTO) {
        Center center = null;
        if (centerDTO != null)
            center = new Center(centerDTO.getId(), centerDTO.getName(), centerDTO.getDescription(), centerDTO.getAddress(), centerDTO.getZipcode(), centerDTO.getPhone(), centerDTO.getEmail(), centerDTO.getWebsite(),centerDTO.getImagePath(),cityConverter.toEntity(centerDTO.getCity()), userConverter.toEntityLazy(centerDTO.getUser()), productConverter.toEntityList(centerDTO.getProducts()));
        return center;
    }

    public Center toEntityLazy(CenterDTO centerDTO){
        Center center = null;
        if (centerDTO != null)
            center = new Center(centerDTO.getId(), centerDTO.getName(), centerDTO.getDescription(), centerDTO.getAddress(), centerDTO.getZipcode(), centerDTO.getPhone(), centerDTO.getEmail(), centerDTO.getWebsite(),centerDTO.getImagePath(),cityConverter.toEntity(centerDTO.getCity()), userConverter.toEntityLazy(centerDTO.getUser()));
        return center;
    }

    @Override
    public CenterDTO toDTO(Center center) {
        CenterDTO centerDTO = null;
        if (center != null)
            centerDTO = new CenterDTO(center.getId(), center.getName(), center.getDescription(), center.getAddress(), center.getZipcode(), center.getPhone(), center.getEmail(), center.getWebsite(),center.getImagePath(),cityConverter.toDTO(center.getCity()), userConverter.toDTOLazy(center.getUser()), productConverter.toDTOList(center.getProducts()));

        return centerDTO;
    }

    public CenterDTO toDTOLazy(Center center){
        CenterDTO centerDTO = null;
        if (center != null)
            centerDTO = new CenterDTO(center.getId(), center.getName(), center.getDescription(), center.getAddress(), center.getZipcode(), center.getPhone(), center.getEmail(), center.getWebsite(),center.getImagePath(),cityConverter.toDTO(center.getCity()), userConverter.toDTOLazy(center.getUser()));

        return centerDTO;
    }
}
