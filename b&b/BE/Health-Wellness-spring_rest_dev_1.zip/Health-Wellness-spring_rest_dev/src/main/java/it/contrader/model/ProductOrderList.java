package it.contrader.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jxl.write.DateTime;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "products_order_list")
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = ProductOrderList.class)
public class ProductOrderList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private float price;
    private float discount;
    private LocalDate startDiscountDate;
    private LocalDate endDiscountDate;

    private boolean deleted;

    private LocalDate createdAt;

    private LocalDate updatedAt;
    private int qty;

    private float pricePurchase;

    private String imagePath;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name ="center_id")
    private Center center;

    @ManyToOne
    @JoinColumn(name ="order_id")
    @JsonManagedReference
    private Order order;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name="product_id")
    private Product product;

    public ProductOrderList(Long id, String name, String description, float price, float discount, LocalDate startDiscountDate, LocalDate endDiscountDate, int qty, float pricePurchase,String imagePath, Center center, Order order, Product product) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.qty = qty;
        this.pricePurchase = pricePurchase;
        this.imagePath = imagePath;
        this.center = center;
        this.order = order;
        this.product = product;
    }

    public ProductOrderList(String name, String description, float price, float discount, LocalDate startDiscountDate, LocalDate endDiscountDate, int qty, float pricePurchase,String imagePath, Center center, Order order, Product product) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.qty = qty;
        this.pricePurchase = pricePurchase;
        this.imagePath = imagePath;
        this.center = center;
        this.order = order;
        this.product = product;
    }

    public ProductOrderList(Long id, String name, String description, float price, float discount, LocalDate startDiscountDate, LocalDate endDiscountDate, int qty, float pricePurchase, String imagePath) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.qty = qty;
        this.pricePurchase = pricePurchase;
        this.imagePath = imagePath;
    }

    @PrePersist
    private void onCreate(){
        this.createdAt = LocalDate.now();
        this.updatedAt = LocalDate.now();
    }

    @PreUpdate
    private void onUpdate(){
        this.updatedAt = LocalDate.now();
    }
}
