package it.contrader.dto;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import it.contrader.model.Treatment;
//import jdk.vm.ci.meta.Local;
import lombok.*;

import java.time.LocalDate;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIdentityInfo(generator= ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = ProductDTO.class)
public class ProductDTO {


    private long id;
    private String title;
    private String description;
    private float price;
    private float discount;
    private int qty;
    private LocalDate startDiscountDate;
    private LocalDate endDiscountDate;

    private String imagePath;

    private boolean deleted = false;

    private LocalDate createdAt;

    private LocalDate updatedAt;
    private CenterDTO center;

    private float currentPrice;

    private TreatmentDTO treatment;

    public ProductDTO(long id,  String title, String description, float price, float discount, int qty, LocalDate startDiscountDate, LocalDate endDiscountDate, CenterDTO center, TreatmentDTO treatment) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.qty = qty;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.center = center;
        this.treatment = treatment;
        this.currentPrice = this.getCurrentPrice(this.price, this.discount, this.startDiscountDate, this.endDiscountDate);
    }

    public ProductDTO( String title,  String description, float price, float discount, int qty, LocalDate startDiscountDate, LocalDate endDiscountDate, CenterDTO center, TreatmentDTO treatment) {
        this.title = title;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.qty = qty;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.center = center;
        this.treatment = treatment;
    }

    public ProductDTO(long id, String title, String description, float price, float discount, int qty, LocalDate startDiscountDate, LocalDate endDiscountDate, TreatmentDTO treatment) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.discount = discount;
        this.qty = qty;
        this.startDiscountDate = startDiscountDate;
        this.endDiscountDate = endDiscountDate;
        this.treatment = treatment;
    }

    private float getCurrentPrice (float price, float discount, LocalDate startDiscountDate, LocalDate endDiscountDate) {
        LocalDate today = LocalDate.now();
        if ((startDiscountDate.isAfter(today) || startDiscountDate.isEqual(today)) && (endDiscountDate.isBefore(today) || endDiscountDate.isEqual(today))) {
            return discount;
        } else {
            return price;
        }
    }
}
